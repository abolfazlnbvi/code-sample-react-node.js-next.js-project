import React from 'react'
function NoPage() {
  return <div>wrong planet: 404</div>
}
export default NoPage