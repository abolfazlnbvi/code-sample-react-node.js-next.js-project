import axios from "axios";

export const baseUrl = "http://localhost:8443"
export const baseUrlUpload = "https://api.amoozkaar.ir"
export const baseUrlImage = "https://api.amoozkaar.ir/images"
export const axiosJWT = axios.create();
